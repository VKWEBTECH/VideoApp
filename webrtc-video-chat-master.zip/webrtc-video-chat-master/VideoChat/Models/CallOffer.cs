﻿namespace VideoChat.Models
{
    public class CallOffer
    {
        public User Caller;
        public User Callee;
    }
}